# LOVABLE PROMPT — ComplianceChain Full Deploy
## Context & Constraints

You are extending the EXISTING AI Cognitive Evidence Platform already built in this Lovable project.
DO NOT recreate from scratch. Analyze the current codebase first, then ADD and MODIFY only what is needed.

The goal: transform the current mock/demo app into a REAL production app, everything inside Lovable (no external backend).
All crypto is done CLIENT-SIDE with Web Crypto API (native browser). Zero external crypto providers.
Blockchain is OPTIONAL — toggled in Settings. Default OFF for testing.

---

## PART 1 — ARCHITECTURE OVERVIEW

```
┌─────────────────────────────────────────────────────────┐
│                    LOVABLE FULL STACK                    │
├─────────────────────────────────────────────────────────┤
│                                                         │
│  FRONTEND (React + TypeScript + Tailwind)               │
│  ├── Pages (existing: compress, execute, cognitive…)    │
│  ├── Settings page (NEW) ← blockchain switch here      │
│  ├── API Keys page (NEW) ← user manages their keys     │
│  └── Components (existing + new ones below)             │
│                                                         │
│  BACKEND (Supabase Edge Functions — serverless)         │
│  ├── /api/compress          → prompt compression        │
│  ├── /api/execute           → calls real AI providers   │
│  ├── /api/cognitive         → reasoning trace parsing   │
│  ├── /api/sign              → returns payload to sign   │
│  ├── /api/bundle            → assembles evidence bundle │
│  ├── /api/blockchain        → anchors IF enabled        │
│  └── /api/verify            → verifies bundle           │
│                                                         │
│  DATABASE (Supabase PostgreSQL)                         │
│  ├── users                                              │
│  ├── api_keys               → encrypted at rest         │
│  ├── executions             → all AI runs               │
│  ├── signatures             → Ed25519 signatures        │
│  ├── bundles                → evidence bundles          │
│  └── settings               → per-user config           │
│                                                         │
│  CRYPTO (100% Web Crypto API — no npm package needed)   │
│  ├── Ed25519 key generation                             │
│  ├── Ed25519 sign / verify                              │
│  ├── SHA-256 hashing                                    │
│  └── AES-256-GCM encryption (for stored API keys)      │
│                                                         │
└─────────────────────────────────────────────────────────┘
```

---

## PART 2 — CRYPTO: WEB CRYPTO API ONLY (no external provider)

This is critical: ALL cryptographic operations use the browser's native Web Crypto API.
No `tweetnacl`, no `noble-ed25519`, no npm crypto package. Zero external dependencies for crypto.

### 2.1 — Why Web Crypto API is enough

| Operation needed | Web Crypto API support | Notes |
|---|---|---|
| SHA-256 hash | ✅ `crypto.subtle.digest` | Native, fast |
| AES-256-GCM encrypt/decrypt | ✅ `crypto.subtle.encrypt` | For storing API keys |
| ECDSA P-256 sign/verify | ✅ `crypto.subtle.sign` | Production-grade signature |
| Key generation | ✅ `crypto.subtle.generateKey` | Non-extractable keys possible |
| Key export/import | ✅ `crypto.subtle.exportKey` | PEM/JWK formats |

> ⚠️ NOTE: Web Crypto API does NOT support Ed25519 in all browsers yet.
> We use **ECDSA P-256** instead. It is:
> - Supported in ALL modern browsers (Chrome, Firefox, Safari, Edge)
> - NIST-standardized, used in TLS
> - 256-bit security
> - Signature size: 64 bytes (compact)
> - Perfectly valid for compliance/audit signatures
> This is a BETTER choice than Ed25519 for a browser-only app.

### 2.2 — Complete crypto utility file

Create `src/utils/crypto.ts`:

```typescript
// src/utils/crypto.ts
// ALL crypto via Web Crypto API. No external dependencies.

// ──────────────────────────────────────────
// 1. SHA-256 HASHING
// ──────────────────────────────────────────
export async function sha256(data: string): Promise<string> {
  const encoder = new TextEncoder();
  const buffer = await crypto.subtle.digest('SHA-256', encoder.encode(data));
  return Array.from(new Uint8Array(buffer))
    .map(b => b.toString(16).padStart(2, '0'))
    .join('');
}

// ──────────────────────────────────────────
// 2. ECDSA P-256 KEY PAIR GENERATION
// ──────────────────────────────────────────
export async function generateSigningKeyPair(): Promise<CryptoKeyPair> {
  return crypto.subtle.generateKey(
    { name: 'ECDSA', namedCurve: 'P-256' },
    true,  // extractable = true (we need to export for storage/display)
    ['sign', 'verify']
  );
}

// ──────────────────────────────────────────
// 3. EXPORT KEYS TO PEM-like strings for display/storage
// ──────────────────────────────────────────
export async function exportPublicKeyPEM(key: CryptoKey): Promise<string> {
  const exported = await crypto.subtle.exportKey('spki', key);
  const base64 = btoa(String.fromCharCode(...new Uint8Array(exported)));
  return `-----BEGIN PUBLIC KEY-----\n${base64.match(/.{1,64}/g)?.join('\n')}\n-----END PUBLIC KEY-----`;
}

export async function exportPrivateKeyPEM(key: CryptoKey): Promise<string> {
  const exported = await crypto.subtle.exportKey('pkcs8', key);
  const base64 = btoa(String.fromCharCode(...new Uint8Array(exported)));
  return `-----BEGIN PRIVATE KEY-----\n${base64.match(/.{1,64}/g)?.join('\n')}\n-----END PRIVATE KEY-----`;
}

// ──────────────────────────────────────────
// 4. IMPORT KEY FROM PEM
// ──────────────────────────────────────────
async function pemToBuffer(pem: string): Promise<ArrayBuffer> {
  const lines = pem.split('\n').filter(l => !l.startsWith('-----'));
  const binary = atob(lines.join(''));
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return bytes.buffer;
}

export async function importPublicKey(pem: string): Promise<CryptoKey> {
  return crypto.subtle.importKey(
    'spki', await pemToBuffer(pem),
    { name: 'ECDSA', hash: 'SHA-256' },
    true, ['verify']
  );
}

export async function importPrivateKey(pem: string): Promise<CryptoKey> {
  return crypto.subtle.importKey(
    'pkcs8', await pemToBuffer(pem),
    { name: 'ECDSA', hash: 'SHA-256' },
    true, ['sign']
  );
}

// ──────────────────────────────────────────
// 5. SIGN A PAYLOAD
// ──────────────────────────────────────────
export async function signPayload(privateKey: CryptoKey, payload: object): Promise<string> {
  const data = JSON.stringify(payload);
  const encoder = new TextEncoder();
  const signature = await crypto.subtle.sign(
    { name: 'ECDSA', hash: { name: 'SHA-256' } },
    privateKey,
    encoder.encode(data)
  );
  return btoa(String.fromCharCode(...new Uint8Array(signature)));
}

// ──────────────────────────────────────────
// 6. VERIFY A SIGNATURE
// ──────────────────────────────────────────
export async function verifySignature(
  publicKeyPEM: string,
  payload: object,
  signatureB64: string
): Promise<boolean> {
  try {
    const publicKey = await importPublicKey(publicKeyPEM);
    const encoder = new TextEncoder();
    const sigBuffer = Uint8Array.from(atob(signatureB64), c => c.charCodeAt(0)).buffer;
    return await crypto.subtle.verify(
      { name: 'ECDSA', hash: { name: 'SHA-256' } },
      publicKey,
      sigBuffer,
      encoder.encode(JSON.stringify(payload))
    );
  } catch {
    return false;
  }
}

// ──────────────────────────────────────────
// 7. AES-256-GCM ENCRYPTION (for API key storage)
// ──────────────────────────────────────────
export async function encryptString(plaintext: string, passphrase: string): Promise<string> {
  const encoder = new TextEncoder();
  // Derive key from passphrase using PBKDF2
  const keyMaterial = await crypto.subtle.importKey(
    'raw', encoder.encode(passphrase), 'PBKDF2', false, ['deriveKey']
  );
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const key = await crypto.subtle.deriveKey(
    { name: 'PBKDF2', salt, iterations: 100000, hash: 'SHA-256' },
    keyMaterial,
    { name: 'AES-GCM', length: 256 },
    false, ['encrypt']
  );
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const encrypted = await crypto.subtle.encrypt(
    { name: 'AES-GCM', iv }, key, encoder.encode(plaintext)
  );
  // Pack: salt (16) + iv (12) + ciphertext
  const combined = new Uint8Array(salt.length + iv.length + encrypted.byteLength);
  combined.set(salt, 0);
  combined.set(iv, salt.length);
  combined.set(new Uint8Array(encrypted), salt.length + iv.length);
  return btoa(String.fromCharCode(...combined));
}

export async function decryptString(cipherB64: string, passphrase: string): Promise<string> {
  const encoder = new TextEncoder();
  const combined = Uint8Array.from(atob(cipherB64), c => c.charCodeAt(0));
  const salt = combined.slice(0, 16);
  const iv = combined.slice(16, 28);
  const ciphertext = combined.slice(28);
  const keyMaterial = await crypto.subtle.importKey(
    'raw', encoder.encode(passphrase), 'PBKDF2', false, ['deriveKey']
  );
  const key = await crypto.subtle.deriveKey(
    { name: 'PBKDF2', salt, iterations: 100000, hash: 'SHA-256' },
    keyMaterial,
    { name: 'AES-GCM', length: 256 },
    false, ['decrypt']
  );
  const decrypted = await crypto.subtle.decrypt(
    { name: 'AES-GCM', iv }, key, ciphertext
  );
  return new TextDecoder().decode(decrypted);
}
```

---

## PART 3 — SUPABASE SCHEMA

Run these in Supabase SQL editor (or as migration):

```sql
-- ─────────────────────────────────
-- TABLE: users (handled by Supabase Auth automatically)
-- ─────────────────────────────────

-- ─────────────────────────────────
-- TABLE: user_settings
-- ─────────────────────────────────
CREATE TABLE IF NOT EXISTS user_settings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  blockchain_enabled BOOLEAN DEFAULT FALSE,
  blockchain_network TEXT DEFAULT 'polygon',  -- polygon | ethereum | base
  signing_public_key_pem TEXT,                 -- user's ECDSA public key (PEM)
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(user_id)
);

-- ─────────────────────────────────
-- TABLE: api_keys (encrypted at rest)
-- ─────────────────────────────────
CREATE TABLE IF NOT EXISTS api_keys (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  provider TEXT NOT NULL,                      -- openai | anthropic | google
  encrypted_key TEXT NOT NULL,                 -- AES-256-GCM encrypted (client-side before insert)
  key_label TEXT,                              -- user-friendly label
  created_at TIMESTAMPTZ DEFAULT NOW(),
  last_used_at TIMESTAMPTZ,
  UNIQUE(user_id, provider)
);

-- ─────────────────────────────────
-- TABLE: executions
-- ─────────────────────────────────
CREATE TABLE IF NOT EXISTS executions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  prompt_id TEXT,
  provider TEXT NOT NULL,
  model_id TEXT NOT NULL,
  temperature FLOAT,
  raw_output TEXT,
  reasoning_trace JSONB,                       -- array of reasoning steps
  trace_quality TEXT,                           -- 'native' | 'structured'
  input_hash TEXT,                             -- SHA-256 of input prompt
  output_hash TEXT,                            -- SHA-256 of raw_output
  tokens_input INTEGER,
  tokens_output INTEGER,
  latency_ms INTEGER,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ─────────────────────────────────
-- TABLE: signatures
-- ─────────────────────────────────
CREATE TABLE IF NOT EXISTS signatures (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  execution_id UUID REFERENCES executions(id),
  signed_payload JSONB NOT NULL,               -- the full payload that was signed
  signature_b64 TEXT NOT NULL,                  -- ECDSA signature (base64)
  public_key_pem TEXT NOT NULL,                 -- public key used (PEM)
  algorithm TEXT DEFAULT 'ECDSA-P256-SHA256',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ─────────────────────────────────
-- TABLE: bundles
-- ─────────────────────────────────
CREATE TABLE IF NOT EXISTS bundles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  execution_id UUID REFERENCES executions(id),
  signature_id UUID REFERENCES signatures(id),
  prompt_hash TEXT,
  output_hash TEXT,
  signature_hash TEXT,
  cognitive_hash TEXT,
  bundle_hash TEXT,                            -- SHA-256 of all hashes combined
  blockchain_enabled BOOLEAN DEFAULT FALSE,
  blockchain_tx_hash TEXT,                     -- NULL if blockchain disabled
  blockchain_network TEXT,
  blockchain_block TEXT,
  verified BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ─────────────────────────────────
-- RLS (Row Level Security)
-- ─────────────────────────────────
ALTER TABLE user_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE api_keys ENABLE ROW LEVEL SECURITY;
ALTER TABLE executions ENABLE ROW LEVEL SECURITY;
ALTER TABLE signatures ENABLE ROW LEVEL SECURITY;
ALTER TABLE bundles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "user own data" ON user_settings FOR ALL USING (user_id = auth.uid());
CREATE POLICY "user own keys" ON api_keys FOR ALL USING (user_id = auth.uid());
CREATE POLICY "user own executions" ON executions FOR ALL USING (user_id = auth.uid());
CREATE POLICY "user own signatures" ON signatures FOR ALL USING (user_id = auth.uid());
CREATE POLICY "user own bundles" ON bundles FOR ALL USING (user_id = auth.uid());
```

---

## PART 4 — SETTINGS PAGE (blockchain switch + signing keys)

Create `src/pages/Settings.tsx`:

The Settings page has 3 sections:

### Section A — Signing Identity
- Button "Generate New Key Pair" → calls `generateSigningKeyPair()` from crypto.ts
- Exports public key PEM → saves to `user_settings.signing_public_key_pem` via Supabase
- Private key PEM shown ONCE in a modal with warning: "Save this. We never store it."
- Shows current public key fingerprint (first 16 chars of SHA-256 of PEM)

### Section B — Blockchain Toggle
A big toggle switch:
- OFF (default): label "Blockchain Anchoring: Disabled"
  - Sub-text: "Signatures are local. Bundles are not anchored to any ledger."
- ON: label "Blockchain Anchoring: Enabled"
  - Network selector appears: Polygon | Ethereum | Base
  - Sub-text: "Bundles will be anchored. Requires RPC key (configure below)."
- Saves to `user_settings.blockchain_enabled` and `blockchain_network`

### Section C — API Keys Management
A table showing configured keys:
| Provider | Label | Status | Last Used | Actions |
|---|---|---|---|---|
| OpenAI | My GPT key | ✅ Valid | 2 min ago | Edit · Delete |
| Anthropic | Claude prod | ✅ Valid | — | Edit · Delete |
| Google | — | ❌ Not set | — | Add |

- "Add Key" button opens a modal:
  - Provider dropdown
  - Label input
  - Key input field
  - On save: encrypt the key CLIENT-SIDE with `encryptString(key, userId)` THEN insert into Supabase
  - The raw key NEVER leaves the browser unencrypted

---

## PART 5 — API KEYS PAGE (detailed key management)

Create `src/pages/ApiKeys.tsx`:

This is a dedicated full page for key management (Settings has a summary, this is the deep view):

- List all keys with cards per provider
- Each card shows: provider logo/icon, label, masked key (sk-****-last4), created date, last used
- "Test Key" button: makes a minimal API call to verify the key works
  - OpenAI: `GET /models` with the key
  - Anthropic: `GET /models` with the key
  - Google: tries listing models
- "Rotate Key" flow: decrypt old → show → user pastes new → encrypt new → update
- Import/Export: export all keys as encrypted JSON (encrypted with a user-chosen master password)

---

## PART 6 — REAL AI PROVIDER INTEGRATION

Replace all mock API calls with real ones. The pattern for each call:

1. User triggers action (e.g., "Execute")
2. Frontend decrypts the relevant API key from Supabase using `decryptString(encryptedKey, userId)`
3. Frontend calls the AI provider DIRECTLY (no backend proxy needed for simple calls)
4. Response is processed and stored in Supabase

### 6.1 — OpenAI

```typescript
// src/utils/providers/openai.ts
export async function callOpenAI(apiKey: string, prompt: string, model: string, temperature: number) {
  const response = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${apiKey}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      model,
      messages: [{ role: 'user', content: prompt }],
      temperature,
      max_tokens: 2048
    })
  });
  if (!response.ok) throw new Error(`OpenAI: ${response.status}`);
  return response.json();
}
```

### 6.2 — Anthropic (Claude)

```typescript
// src/utils/providers/anthropic.ts
export async function callAnthropic(apiKey: string, prompt: string, model: string, temperature: number) {
  const response = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'x-api-key': apiKey,
      'anthropic-version': '2023-06-01',
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      model,
      max_tokens: 2048,
      temperature,
      messages: [{ role: 'user', content: prompt }]
    })
  });
  if (!response.ok) throw new Error(`Anthropic: ${response.status}`);
  return response.json();
}
```

### 6.3 — Google Gemini

```typescript
// src/utils/providers/google.ts
export async function callGemini(apiKey: string, prompt: string, model: string, temperature: number) {
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${apiKey}`;
  const response = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      contents: [{ parts: [{ text: prompt }] }],
      generationConfig: { temperature, maxOutputTokens: 2048 }
    })
  });
  if (!response.ok) throw new Error(`Gemini: ${response.status}`);
  const data = await response.json();
  // Extract thought signatures if present (Gemini 2.0 Flash Thinking)
  const thoughtSignatures = data.candidates?.[0]?.groundingMetadata?.thoughtSignatures || [];
  return { data, thoughtSignatures };
}
```

### 6.4 — Enhanced prompts for reasoning trace

For Claude and GPT, wrap the user prompt to extract structured reasoning:

```typescript
export function wrapPromptForReasoning(userPrompt: string, provider: string): string {
  if (provider === 'google') return userPrompt; // Gemini has native thought signatures

  const reasoningWrapper = `You must structure your response as follows:

<reasoning>
<step id="1" type="analysis">
[Your initial analysis of the request]
</step>
<step id="2" type="evidence">
[Key evidence or data points you are considering]
</step>
<step id="3" type="evaluation">
[Your evaluation and weighing of options]
</step>
<step id="4" type="conclusion">
[Your final conclusion and reasoning]
</step>
</reasoning>

<answer>
[Your complete answer here]
</answer>

---
USER REQUEST:
${userPrompt}`;

  return reasoningWrapper;
}

export function parseReasoningTrace(responseText: string, provider: string): { answer: string; steps: ReasoningStep[] } {
  // Extract <reasoning>...</reasoning> block
  const reasoningMatch = responseText.match(/<reasoning>([\s\S]*?)<\/reasoning>/);
  const answerMatch = responseText.match(/<answer>([\s\S]*?)<\/answer>/);

  const steps: ReasoningStep[] = [];
  if (reasoningMatch) {
    const stepRegex = /<step id="(\d+)" type="(\w+)">([\s\S]*?)<\/step>/g;
    let match;
    while ((match = stepRegex.exec(reasoningMatch[1])) !== null) {
      steps.push({
        step_index: parseInt(match[1]),
        type: match[2] as any,
        content: match[3].trim()
      });
    }
  }

  return {
    answer: answerMatch ? answerMatch[1].trim() : responseText,
    steps
  };
}
```

---

## PART 7 — BLOCKCHAIN (conditional, OFF by default)

### 7.1 — Architecture when blockchain is OFF (default)
- Everything works exactly the same
- Bundles are created and stored in Supabase
- `blockchain_enabled = false`, `blockchain_tx_hash = NULL`
- Verification checks signatures locally only
- Badge on bundle: "Local Signature" (green)

### 7.2 — Architecture when blockchain is ON
When user enables blockchain in Settings, bundles are additionally anchored.
We use a PUBLIC RPC endpoint (no API key needed for read, but writing needs a funded wallet).

For the MVP, use a SIMULATED blockchain anchor that:
- Generates a realistic-looking tx hash
- Stores a fake block number
- Shows the flow correctly in the UI
- Has a clear label: "Simulated Anchor (enable real RPC in settings for production)"

This way users see the full flow without needing a real funded wallet.

When the user wants to go REAL:
- They add an RPC private key in Settings
- We switch to real Web3 calls

```typescript
// src/utils/blockchain.ts

export interface BlockchainConfig {
  enabled: boolean;
  network: 'polygon' | 'ethereum' | 'base';
  rpcUrl?: string;        // Optional: real RPC endpoint
  privateKey?: string;    // Optional: wallet private key (for real anchoring)
}

export async function anchorBundle(bundleHash: string, config: BlockchainConfig): Promise<{
  tx_hash: string;
  block_number: number;
  network: string;
  simulated: boolean;
}> {
  if (!config.enabled) {
    throw new Error('Blockchain anchoring is disabled');
  }

  // If no real RPC configured → simulate
  if (!config.rpcUrl || !config.privateKey) {
    return simulateAnchor(bundleHash, config.network);
  }

  // Real anchoring would go here (Web3 calls)
  // For now, always simulate unless real keys provided
  return simulateAnchor(bundleHash, config.network);
}

function simulateAnchor(bundleHash: string, network: string) {
  // Deterministic fake tx hash based on bundle hash (looks realistic)
  const fakeTx = '0x' + bundleHash.slice(0, 64);
  const fakeBlock = Math.floor(Math.random() * 50000000) + 50000000;

  return {
    tx_hash: fakeTx,
    block_number: fakeBlock,
    network,
    simulated: true
  };
}
```

### 7.3 — UI badges
- Blockchain OFF → bundle card shows: 🔒 "Signed Locally"
- Blockchain ON (simulated) → shows: ⛓️ "Anchored (Simulated)" with yellow badge
- Blockchain ON (real) → shows: ⛓️ "Anchored on Polygon" with green badge + explorer link

---

## PART 8 — FULL SIGNING FLOW (replaces the current mock)

The signing flow in the Signature module now works like this:

1. User clicks "Sign this execution"
2. Frontend builds the payload:
```typescript
const payload = {
  execution_id: execution.id,
  model: {
    provider: execution.provider,
    model_id: execution.model_id,
  },
  input_hash: execution.input_hash,      // SHA-256 computed client-side
  output_hash: execution.output_hash,    // SHA-256 computed client-side
  reasoning_trace_hash: await sha256(JSON.stringify(execution.reasoning_trace)),
  timestamps: {
    execution_created: execution.created_at,
    signed_at: new Date().toISOString()
  },
  signer: {
    public_key_fingerprint: publicKeyFingerprint  // first 16 chars of SHA-256(PEM)
  }
};
```
3. Frontend signs with user's private key (stored in memory only, loaded from the PEM they saved):
```typescript
const signature = await signPayload(privateKey, payload);
```
4. Frontend saves to Supabase: `{ signed_payload: payload, signature_b64: signature, public_key_pem }`
5. UI shows: signature ID, algorithm (ECDSA-P256-SHA256), public key fingerprint, timestamp

---

## PART 9 — VERIFICATION FLOW

Verification checks 3 things:

1. **Signature integrity**: Re-verifies ECDSA signature against the stored payload and public key
2. **Hash integrity**: Re-computes SHA-256 of the original output and compares to `output_hash` in payload
3. **Blockchain** (if was anchored): Shows the tx hash and block (for simulated, shows "Simulated" label)

All 3 checks shown as a checklist in the UI:
```
✅ Signature Valid     — ECDSA-P256 verified
✅ Hash Integrity     — SHA-256 matches original output
⚠️ Blockchain         — Simulated anchor (tx: 0x7f3a...)
```

---

## PART 10 — COMPONENTS TO CREATE/MODIFY

### NEW: `src/pages/Settings.tsx`
Full settings page with 3 sections (see Part 4)

### NEW: `src/pages/ApiKeys.tsx`
Dedicated API keys management page (see Part 5)

### NEW: `src/utils/crypto.ts`
All crypto utilities (see Part 2)

### NEW: `src/utils/providers/openai.ts`
Real OpenAI integration (see Part 6.1)

### NEW: `src/utils/providers/anthropic.ts`
Real Anthropic integration (see Part 6.2)

### NEW: `src/utils/providers/google.ts`
Real Gemini integration with thought signature extraction (see Part 6.3)

### NEW: `src/utils/providers/reasoningWrapper.ts`
Enhanced prompt wrapping + parsing (see Part 6.4)

### NEW: `src/utils/blockchain.ts`
Blockchain anchor logic with simulate/real switch (see Part 7)

### MODIFY: `src/pages/AIExecution.tsx` (or wherever Execute lives)
- Replace mock `api.executeAI()` with real provider calls
- Decrypt API key → call real provider → parse reasoning → store in Supabase

### MODIFY: `src/pages/AISignature.tsx` (or wherever Signature lives)
- Replace mock signing with real `signPayload()` from crypto.ts
- Real verification with `verifySignature()`

### MODIFY: `src/pages/EvidenceBundle.tsx` (or wherever Bundle lives)
- After creating bundle, check `settings.blockchain_enabled`
- If ON → call `anchorBundle()` → store tx hash
- Display appropriate badge

### MODIFY: Navigation/Sidebar
- Add "Settings" route
- Add "API Keys" route

---

## PART 11 — INSTRUCTIONS FOR LOVABLE

1. First, READ the existing codebase to understand current structure and component names
2. Create the Supabase tables (Part 3) — add as a migration or note for manual setup
3. Create `src/utils/crypto.ts` exactly as shown in Part 2
4. Create the 3 provider files (Parts 6.1, 6.2, 6.3)
5. Create `src/utils/providers/reasoningWrapper.ts` (Part 6.4)
6. Create `src/utils/blockchain.ts` (Part 7)
7. Create `src/pages/Settings.tsx` (Part 4)
8. Create `src/pages/ApiKeys.tsx` (Part 5)
9. Modify existing execution page to use real providers
10. Modify existing signature page to use real crypto
11. Modify existing bundle page to conditionally anchor
12. Update navigation

Do NOT break any existing functionality. Add and modify only.
Use the existing design system (Tailwind classes, shadcn components, colors) for consistency.
