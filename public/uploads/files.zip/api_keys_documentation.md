# API Keys — Guide d'obtention

## Comment obtenir chaque clé

---

### 🟢 OpenAI (GPT-4, GPT-4o)

1. Aller sur [https://platform.openai.com](https://platform.openai.com)
2. Créer un compte ou se connecter
3. Menu gauche → **API Keys**
4. Cliquer **+ Create project key** (ou **+ New secret key**)
5. Copier la clé : elle commence par `sk-`
6. ⚠️ Elle n'est affichée qu'UNE SEULE FOIS — la sauvegarder immédiatement

**Permissions nécessaires :** `chat.completions` en write

**Coût estimé pour tests :**
- GPT-4o-mini : ~$0.15 / 1M tokens input
- GPT-4o : ~$2.50 / 1M tokens input

---

### 🟣 Anthropic (Claude)

1. Aller sur [https://console.anthropic.com](https://console.anthropic.com)
2. Créer un compte ou se connecter
3. Menu gauche → **API Keys**
4. Cliquer **+ Create API Key**
5. Copier la clé : elle commence par `sk-ant-`
6. ⚠️ Elle n'est affichée qu'UNE SEULE FOIS

**Permissions nécessaires :** Full access (par défaut)

**Coût estimé pour tests :**
- Claude Haiku : ~$0.25 / 1M tokens input
- Claude Sonnet : ~$3.00 / 1M tokens input

---

### 🔵 Google (Gemini)

Deux options selon le niveau :

#### Option A — Google AI Studio (simple, pour tests)
1. Aller sur [https://aistudio.google.com](https://aistudio.google.com)
2. Se connecter avec un compte Google
3. Cliquer **Get API Key** (en haut à droite)
4. Copier la clé

**Coût :** Gemini 1.5 Flash est gratuit jusqu'à un certain quota

#### Option B — Google Cloud (pour production)
1. Aller sur [https://console.cloud.google.com](https://console.cloud.google.com)
2. Créer un projet
3. Activer l'API **Generative Language API**
4. Aller dans **APIs & Services → Credentials**
5. Créer une clé API
6. Restreindre la clé à l'API Generative Language uniquement

**Note pour Thought Signatures :** Le modèle `gemini-2.0-flash-thinking-exp` est requis pour avoir les thought signatures natives. Il n'est disponible qu'avec l'API Google Cloud ou AI Studio.

---

### ⛓️ Blockchain RPC (optionnel — seulement si vous activez le blockchain)

Par défaut le blockchain est **simulé**. Si vous voulez un ancrage réel :

#### Polygon (recommandé — pas cher)
1. Aller sur [https://dashboard.quicknode.com](https://dashboard.quicknode.com) (gratuit tier dispo)
2. Créer un endpoint Polygon Mainnet
3. Copier l'URL RPC complète
4. Vous aurez aussi besoin d'un **wallet privé** avec quelques MATIC (~$1 suffit pour des dizaines d'ancrages)

#### Obtenir du MATIC pour les frais
1. Acheter sur un exchange (Binance, Coinbase…)
2. Envoyer sur votre wallet (MetaMask par exemple)
3. Copier la clé privée du wallet dans les settings

**Coût par ancrage :** ~$0.001 sur Polygon

---

## Résumé rapide

| Provider | URL | Préfixe clé | Gratuit ? |
|---|---|---|---|
| OpenAI | platform.openai.com | `sk-` | Non (crédit gratuit au début) |
| Anthropic | console.anthropic.com | `sk-ant-` | Non (crédit gratuit au début) |
| Google AI Studio | aistudio.google.com | — | Oui (quota limité) |
| Polygon RPC | quicknode.com | URL complète | Oui (tier gratuit) |

---

## Sécurité

- Vos clés sont chiffrées **côté navigateur** avant d'être stockées (AES-256-GCM)
- Le serveur ne voit jamais vos clés en clair
- Si vous perdez votre mot de passe Supabase, les clés sont **irrecouvrables** (re-créez-les sur chaque provider)
- Ne partagez jamais vos clés — chaque utilisateur en a les siennes
